import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

// Voyant — Cinematic destination hero (Globe Express style).
// Full-bleed hero photo + overlaid headline + destination card row +
// carousel + counter. Photos are GRADIENT PLACEHOLDERS for now:
// to use real images, set `img` on a destination and it renders as
// a background-image (swap is one line per card).

const C = {
  forest: "#2F5D50", sage: "#7BA697", sageDeep: "#4E7C6C",
  gold: "#E0A458", goldDeep: "#C98A3C",
  navy: "#243B34", white: "#FFFFFF", ink: "#1A2B26",
  coral: "#E0A458", coralLight: "#E8C07A", // aliased to gold so existing refs stay warm
}

// each destination: name, region, and either an `img` URL (real photo,
// later) or a gradient placeholder shown until you add one.
const DESTS = [
  { name: "Goa", region: "India · Beaches", grad: ["#E8C07A", "#C98A3C"], img: null },
  { name: "Manali", region: "Himachal · Mountains", grad: ["#7BA697", "#2F5D50"], img: null },
  { name: "Kyoto", region: "Japan · Culture", grad: ["#9CB89A", "#4E7C6C"], img: null },
  { name: "Santorini", region: "Greece · Coast", grad: ["#7FB6C8", "#2E6E78"], img: null },
  { name: "Bali", region: "Indonesia · Tropics", grad: ["#8FC8A0", "#3E8E6A"], img: null },
];

const bgOf = (d) =>
  d.img
    ? `linear-gradient(180deg, rgba(20,21,40,0) 40%, rgba(20,21,40,0.75) 100%), url(${d.img}) center/cover`
    : `linear-gradient(180deg, rgba(20,21,40,0.05) 30%, rgba(20,21,40,0.7) 100%), linear-gradient(150deg, ${d.grad[0]}, ${d.grad[1]})`;

export default function VoyantHero() {
  const navigate = useNavigate();
  const [active, setActive] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const [interacted, setInteracted] = useState(0); // bump to reset the auto-advance timer
  useEffect(() => { const t = setTimeout(() => setLoaded(true), 80); return () => clearTimeout(t); }, []);

  // auto-advance to the next destination every 5s; resets whenever the
  // user interacts (the `interacted` dep restarts this effect).
  useEffect(() => {
    const id = setInterval(() => setActive((a) => (a + 1) % DESTS.length), 5000);
    return () => clearInterval(id);
  }, [interacted]);

  const hero = DESTS[active];
  const go = (i) => { setActive(i); setInteracted((n) => n + 1); };
  const next = () => { setActive((a) => (a + 1) % DESTS.length); setInteracted((n) => n + 1); };
  const prev = () => { setActive((a) => (a - 1 + DESTS.length) % DESTS.length); setInteracted((n) => n + 1); };

  const reveal = (i) => ({
    opacity: loaded ? 1 : 0,
    transform: loaded ? "translateY(0)" : "translateY(20px)",
    transition: `opacity 700ms ease-out ${i*120}ms, transform 700ms cubic-bezier(0.22,1,0.36,1) ${i*120}ms`,
  });

  return (
    <div style={{
      position: "relative", minHeight: "100vh", overflow: "hidden",
      fontFamily: "'Inter', system-ui, sans-serif", color: C.white,
      // full-bleed hero background = the active destination
      background: hero.img
        ? `linear-gradient(90deg, rgba(20,21,40,0.75) 0%, rgba(20,21,40,0.3) 45%, rgba(20,21,40,0.15) 100%), url(${hero.img}) center/cover`
        : `linear-gradient(90deg, rgba(20,21,40,0.78) 0%, rgba(20,21,40,0.35) 50%, rgba(20,21,40,0.2) 100%), linear-gradient(135deg, ${hero.grad[0]}, ${hero.grad[1]})`,
      transition: "background 600ms ease-out",
    }}>
      {/* NAVBAR */}
      <header style={{ position: "relative", zIndex: 5, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "26px 52px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
          <svg width="24" height="20" viewBox="0 0 26 22"><path d="M13 0 L26 22 L0 22Z" fill={C.white}/><path d="M13 0 L19.5 11 L6.5 11Z" fill={C.coral}/></svg>
          <span style={{ font: "600 1.5rem 'Fraunces', serif", letterSpacing: "0.02em" }}>VOYANT</span>
        </div>
        <nav style={{ display: "flex", gap: 30 }}>
          <span onClick={() => navigate("/how-ai")} style={{ font: "600 0.78rem system-ui", letterSpacing: "0.05em", color: "rgba(255,255,255,0.85)", cursor: "pointer", textTransform: "uppercase" }}>How our AI works</span>
        </nav>
        <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
          <span onClick={() => navigate("/auth")} style={{ font: "600 0.8rem system-ui", cursor: "pointer", opacity: 0.9 }}>Sign in</span>
          <button onClick={() => navigate("/auth")} style={{ border: "none", background: C.coral, color: C.white, font: "700 0.8rem system-ui", padding: "9px 18px", borderRadius: 99, cursor: "pointer" }}>Get started</button>
        </div>
      </header>

      {/* HERO CONTENT */}
      <div style={{ position: "relative", zIndex: 4, padding: "60px 52px 0", maxWidth: 640 }}>
        <div style={{ ...reveal(0), font: "600 0.82rem system-ui", letterSpacing: "0.22em", textTransform: "uppercase", opacity: 0.85, marginBottom: 16 }}>
          ✦ {hero.region}
        </div>
        <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Caveat:wght@600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
        <h1 style={{ ...reveal(1), font: "600 5rem 'Fraunces', serif", margin: 0, lineHeight: 0.95, letterSpacing: "-0.02em", textTransform: "uppercase", textShadow: "0 4px 30px rgba(0,0,0,0.3)" }}>
          {hero.name}
        </h1>
        <p style={{ ...reveal(2), font: "400 1.05rem system-ui", color: "rgba(255,255,255,0.85)", maxWidth: 400, margin: "22px 0 0", lineHeight: 1.6 }}>
          Picked by your group, decided by a vote. Start planning the trip everyone actually wants.
        </p>
        <div style={{ ...reveal(3), display: "flex", gap: 14, marginTop: 32, alignItems: "center" }}>
          <button onClick={() => navigate("/auth")} style={{ border: "none", background: C.coral, color: C.white, font: "700 0.92rem system-ui", padding: "15px 30px", borderRadius: 99, cursor: "pointer", boxShadow: "0 12px 30px rgba(232,103,76,0.45)" }}>
            Start a trip
          </button>
        </div>
      </div>

      {/* DESTINATION CARD ROW + controls (bottom) */}
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, zIndex: 4, padding: "0 52px 40px" }}>
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 24 }}>
          {/* carousel arrows + counter */}
          <div style={{ ...reveal(4), display: "flex", alignItems: "center", gap: 18, paddingBottom: 8 }}>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={prev} style={{ width: 44, height: 44, borderRadius: 99, border: "1.5px solid rgba(255,255,255,0.5)", background: "rgba(255,255,255,0.1)", backdropFilter: "blur(6px)", color: C.white, cursor: "pointer", fontSize: "1rem" }}>‹</button>
              <button onClick={next} style={{ width: 44, height: 44, borderRadius: 99, border: "1.5px solid rgba(255,255,255,0.5)", background: "rgba(255,255,255,0.1)", backdropFilter: "blur(6px)", color: C.white, cursor: "pointer", fontSize: "1rem" }}>›</button>
            </div>
            <div style={{ font: "300 2.4rem system-ui", letterSpacing: "0.02em", opacity: 0.9 }}>
              {String(active + 1).padStart(2, "0")}
              <span style={{ font: "400 0.9rem system-ui", opacity: 0.6 }}> / {String(DESTS.length).padStart(2, "0")}</span>
            </div>
          </div>

          {/* cards — show the UPCOMING destinations (after the active one) */}
          <div style={{ display: "flex", gap: 18, overflow: "hidden" }}>
            {DESTS.map((_, k) => {
              // index of the k-th upcoming destination after the active one
              const idx = (active + 1 + k) % DESTS.length;
              if (k >= DESTS.length - 1) return null; // show all others (not the active)
              const d = DESTS[idx];
              return (
                <button
                  key={d.name}
                  onClick={() => go(idx)}
                  style={{
                    position: "relative", flexShrink: 0,
                    width: 190, height: 280,
                    borderRadius: 18, border: "none", cursor: "pointer",
                    background: bgOf(d), backgroundSize: "cover",
                    boxShadow: "0 14px 36px rgba(0,0,0,0.35)",
                    transform: k === 0 ? "translateY(-14px)" : "translateY(0)",
                    transition: "transform 360ms cubic-bezier(0.22,1,0.36,1)",
                    overflow: "hidden", textAlign: "left",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.transform = "translateY(-18px)")}
                  onMouseLeave={(e) => (e.currentTarget.style.transform = k === 0 ? "translateY(-14px)" : "translateY(0)")}
                >
                  <div style={{ position: "absolute", left: 16, right: 16, bottom: 16 }}>
                    <div style={{ font: "500 0.66rem 'Inter'", letterSpacing: "0.08em", color: "rgba(255,255,255,0.85)", textTransform: "uppercase", marginBottom: 4 }}>{d.region}</div>
                    <div style={{ font: "600 1.25rem 'Fraunces', serif", color: C.white, lineHeight: 1.1 }}>{d.name}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}